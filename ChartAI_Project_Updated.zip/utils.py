import pandas as pd
import streamlit as st
import seaborn as sns
import matplotlib.pyplot as plt
import statsmodels.api as sm
from textblob import TextBlob
from sklearn.ensemble import IsolationForest
from prophet import Prophet

def load_data(file):
    if file.name.endswith(".csv") or file.name.endswith(".txt"):
        return pd.read_csv(file)
    else:
        return pd.read_excel(file)

def generate_stats(df):
    return df.describe()

def generate_charts(df):
    numeric_cols = df.select_dtypes(include=["number"]).columns.tolist()
    if not numeric_cols:
        st.warning("No numeric columns found for visualization.")
        return
    chart_type = st.selectbox("Select chart type", ["Line", "Bar", "Box", "Histogram", "Heatmap"])
    col1 = st.selectbox("X-axis", df.columns)
    col2 = st.selectbox("Y-axis", numeric_cols)

    fig, ax = plt.subplots()
    if chart_type == "Line":
        sns.lineplot(data=df, x=col1, y=col2, ax=ax)
    elif chart_type == "Bar":
        sns.barplot(data=df, x=col1, y=col2, ax=ax)
    elif chart_type == "Box":
        sns.boxplot(data=df, x=col1, y=col2, ax=ax)
    elif chart_type == "Histogram":
        df[col2].hist(ax=ax)
    elif chart_type == "Heatmap":
        sns.heatmap(df.corr(), annot=True, cmap="coolwarm", ax=ax)

    st.pyplot(fig)

def perform_regression(df):
    numeric_cols = df.select_dtypes(include=["number"]).columns
    if len(numeric_cols) < 2:
        st.warning("Not enough numeric columns for regression.")
        return
    x_col = st.selectbox("Independent Variable", numeric_cols)
    y_col = st.selectbox("Dependent Variable", numeric_cols)

    X = sm.add_constant(df[[x_col]])
    y = df[y_col]
    model = sm.OLS(y, X).fit()
    st.text(model.summary())

def perform_forecast(df):
    if "Date" not in df.columns:
        st.warning("Column 'Date' required for forecasting.")
        return
    df['Date'] = pd.to_datetime(df['Date'])
    y_col = st.selectbox("Value to Forecast", df.select_dtypes(include=["number"]).columns)
    forecast_df = df[["Date", y_col]].rename(columns={"Date": "ds", y_col: "y"})
    model = Prophet()
    model.fit(forecast_df)
    future = model.make_future_dataframe(periods=7)
    forecast = model.predict(future)
    st.write(forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].tail())
    fig = model.plot(forecast)
    st.pyplot(fig)

def analyze_sentiment(df):
    text_col = st.selectbox("Select text column", df.select_dtypes(include=["object"]).columns)
    if text_col:
        df["Sentiment"] = df[text_col].astype(str).apply(lambda x: TextBlob(x).sentiment.polarity)
        st.write(df[[text_col, "Sentiment"]].head())

def detect_anomalies(df):
    numeric_cols = df.select_dtypes(include=["number"]).columns
    if len(numeric_cols) == 0:
        st.warning("No numeric columns found for anomaly detection.")
        return
    col = st.selectbox("Select column for anomaly detection", numeric_cols)
    clf = IsolationForest(contamination=0.1)
    df["Anomaly"] = clf.fit_predict(df[[col]])
    st.write(df[[col, "Anomaly"]])