import streamlit as st
import pandas as pd
from utils import load_data, generate_stats, perform_regression, perform_forecast, analyze_sentiment, detect_anomalies, generate_charts

st.set_page_config(page_title="ChartAI", layout="wide")
st.title("📊 ChartAI – AI-powered Research & Business Data Analyzer")

uploaded_file = st.file_uploader("Upload your Excel/CSV/TXT file", type=["csv", "xls", "xlsx", "txt"])
if uploaded_file:
    df = load_data(uploaded_file)
    st.write("### Data Preview", df.head())

    with st.expander("📈 Descriptive Statistics"):
        stats = generate_stats(df)
        st.dataframe(stats)

    with st.expander("📊 Visualizations"):
        generate_charts(df)

    with st.expander("🔍 Regression Analysis"):
        perform_regression(df)

    with st.expander("📆 Time Series Forecasting"):
        perform_forecast(df)

    with st.expander("💬 Sentiment Analysis"):
        analyze_sentiment(df)

    with st.expander("🚨 Anomaly Detection"):
        detect_anomalies(df)

st.sidebar.title("ChartAI")
st.sidebar.info("Upload a dataset to begin analysis.")